from rclpy.time import Time
from utilities import Logger

# Controller type
P=0 # poportional
PD=1 # proportional and derivative
PI=2 # proportional and integral
PID=3 # proportional, integral, derivative

class PID_ctrl:
    
    def __init__(self, type_, kp=1.2,kv=0.8,ki=0.2, history_length=3, filename_="errors.csv"):
        
        # Data for the controller
        self.history_length=history_length
        self.history=[]
        self.type=type_

        # Controller gains
        self.kp=kp    # proportional gain
        self.kv=kv    # derivative gain
        self.ki=ki    # integral gain
        
        self.logger=Logger(filename_)
        # Remeber that you are writing to the file named filename_ or errors.csv the following:
            # error, error_dot, error_int and time stamp

    
    def update(self, stamped_error, status):
        
        if status == False:
            self.__update(stamped_error)
            return 0.0
        else:
            return self.__update(stamped_error)

        
    def __update(self, stamped_error):
        
        latest_error=stamped_error[0]
        stamp=stamped_error[1]
        
        self.history.append(stamped_error)        
        
        if (len(self.history) > self.history_length):
            self.history.pop(0)
        
        # If insufficient data points, use only the proportional gain
        if (len(self.history) != self.history_length):
            return self.kp * latest_error
        
        # Compute the error derivative
        dt_avg=0
        error_dot=0
        valid_intervals=0
        
        for i in range(1, len(self.history)):
            
            t0=Time.from_msg(self.history[i-1][1])
            t1=Time.from_msg(self.history[i][1])
            
            dt=(t1.nanoseconds - t0.nanoseconds) / 1e9
            
            dt_avg+=dt

            # use constant dt if the messages arrived inconsistent
            # for example dt=0.1 overwriting the calculation          
            
            # TODO - DONE - Part 5: calculate the error dot 
            # Repeated timestamps do not define a derivative.
            if dt <= 0.0:
                continue

            error_change = self.history[i][0] - self.history[i - 1][0]
            error_dot += error_change / dt
            valid_intervals += 1 

            
        # average the interval slopes, not the number of samples 
        if valid_intervals > 0:
            error_dot /= valid_intervals
        
        # Compute the error integral
        sum_=0
        # TODO - DONE - Part 5: Gather the integration       
        if not hasattr(self, "error_integral"):
            self.error_integral = 0.0

            # On the first calculation, include all available startup intervals.
            first_interval = 1
        else:
            # On later calculations, add only the newest interval.
            first_interval = len(self.history) - 1

        for i in range(first_interval, len(self.history)):
            t0 = Time.from_msg(self.history[i - 1][1])
            t1 = Time.from_msg(self.history[i][1])
            dt = (t1.nanoseconds - t0.nanoseconds) / 1e9

            # Skip repeated or backwards timestamps.
            if dt <= 0.0:
                continue

            e0 = self.history[i - 1][0]
            e1 = self.history[i][0]

            # Add the area under the error curve over this interval.
            self.error_integral += 0.5 * (e0 + e1) * dt

        # Use the accumulated result for logging and the controller.
        error_int = self.error_integral
        
        # TODO - DONE - Part 4: Log your errors
        # record error and its timestamp so we can plot afterwards
        self.logger.log_values([
            latest_error,
            error_dot,
            error_int,
            Time.from_msg(stamp).nanoseconds,
        ])
        
        # TODO - DONE - Part 4: Implement the control law of P-controller
        if self.type == P:
            return self.kp * latest_error
        
        # TODO - DONE - Part 5: Implement the control law corresponding to each type of controller
        elif self.type == PD:
            return (
                self.kp * latest_error
                + self.kv * error_dot
            )
        
        elif self.type == PI:
            return (
                self.kp * latest_error
                + self.ki * error_int
            )
        
        elif self.type == PID:
            return (
                self.kp * latest_error
                + self.kv * error_dot
                + self.ki * error_int
            )