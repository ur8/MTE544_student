# MTE 544 Lab 3 - Group 22 pre-lab submission

Commented first implementation of the six-state EKF using odometry velocities
and IMU accelerations, including synchronized fusion, controller integration,
CSV logging, a trial recorder and plot generation.

Completed preparation:
- Derived and implemented both models, Jacobians and EKF prediction/update.
- Passed 14 automated checks and a separate synthetic-sensor ROS integration check.
- Recorded a Gazebo spiral baseline and two Q variations and two R variations.
- Completed a Gazebo point-controller run using Q = 0.5 I6 and R = 0.5 I4.
- The point run printed "reached goal", exited with code 0, and confirmed a
  zero-velocity publication. It contains 870 samples spanning
  29.546 simulation seconds.
- Position goal: (-1, -1) m. Final estimated distance is
  0.992 cm (threshold 1 cm); odometry
  distance is 0.504 cm. Odometry is
  not independent ground truth.
- Original CSVs, actual covariance settings, plots and saved code are included.

The implementation is a preliminary best attempt. Physical-robot tests, final
covariance tuning and TA demonstrations remain for the scheduled lab.

Known observation/question for troubleshooting: during steady spiral motion,
IMU forward acceleration averages approximately -0.054 to -0.058 m/s^2 while
odometry speed is nearly constant. Sensor-frame/model assumptions need checking.

Read docs/lab3_ekf.md for derivations and commands. Automated checks:

    python3 -m pytest -q tests

No final report is included. Preliminary code is due 24 hours before the lab;
the working simulation must be demonstrated and explained in its first 20 minutes.
